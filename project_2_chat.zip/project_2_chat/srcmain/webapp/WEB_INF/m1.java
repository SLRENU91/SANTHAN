class Website
{
static int no_of_users=0;
public Website()
{
System.out.println(no_of_users++);
}
public static void m1()
{
System.out.println("im in static");
}
static
{
System.out.println("im in static block");
}
public static void main(String arg[])
{
System.out.println("im in main");
Website p1=new Website();
System.out.println("info"+no_of _users);
Website p2=new Website();
System.out.println("info"+no_of _users);
Website p3=new Website();
System.out.println("info"+no_of _users);
m1();
Website.m1();
}
}

