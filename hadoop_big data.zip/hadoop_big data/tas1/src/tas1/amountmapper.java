package tas1;

public class amountmapper {

}
