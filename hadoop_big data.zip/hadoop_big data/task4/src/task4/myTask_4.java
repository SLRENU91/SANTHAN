package task4;
import java.io.IOException;



import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class myTask_4 {

public static void main(String[] args) throws IOException, ClassNotFoundException{
Configuration conf = new Configuration();
Job j =new Job(conf,"myTask_4");
j.setJarByClass(myTask_4.class);
j.setMapperClass(mymapper.class);
j.setReducerClass(myreducer.class);
j.setNumReduceTasks(1);
j.setMapOutputKeyClass(Text.class);
j.setMapOutputValueClass(IntWritable.class);

FileInputFormat.addInputPath(j,new Path(args[0]));
FileOutputFormat.setOutputPath(j, new Path(args[1]));

try {
	System.exit(j.waitForCompletion(true)?0:1);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

}
}
