package task4;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myreducer extends Reducer<Text, IntWritable,Text, IntWritable>
{
public void reduce(Text inpKey,Iterable<IntWritable>inpVal, Context cont) throws IOException, InterruptedException {
	int count=0;
	for(IntWritable singlevalue: inpVal){
		count++;
	}
	cont.write(inpKey,new IntWritable(count));
}
}