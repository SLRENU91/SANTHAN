package task4;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class mymapper extends Mapper<LongWritable,Text,Text,IntWritable>
{
public void map(LongWritable Key,Text val,Context cont)throws IOException{
String input =val.toString();
String[] inpval=input.split(",");
String[] date=inpval[1].split("-");
for(String eachVal:date)
{
	Text outputKey =new Text(date[0]);
	IntWritable outputVal=new IntWritable(1);
	try {
		cont.write(outputKey, outputVal);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
}