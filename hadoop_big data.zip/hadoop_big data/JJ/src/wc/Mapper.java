package wc;

public class Mapper {

}
