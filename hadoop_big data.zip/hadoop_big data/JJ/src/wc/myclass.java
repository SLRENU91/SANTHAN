package wc;

public class myclass extends Mapper {
	

}
