package map;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.*;
public class mapper1 extends Mapper<LongWritable, Text, Text, IntWritable> {
	public void set(Context con)
	{
		FileInputStream fis=new FileInputStream("");
	}
}
