package last;

import java.io.IOException;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleMaker;

public class last_name extends EvalFunc<String> {

	
private Tuple arg0;

public String ex(TupleMaker args0) throws IOException
{
	String log =arg0.get(0).toString();
	String[] logparts=log.split("",5);
	return logparts[4];
}

@Override
public String exec(Tuple arg0) throws IOException {
	// TODO Auto-generated method stub
	return null;
}
}