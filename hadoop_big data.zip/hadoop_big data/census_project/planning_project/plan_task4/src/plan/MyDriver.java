package plan;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class MyDriver {
	
	public static void main(String args[]) throws IOException, InterruptedException, ClassNotFoundException
	{ 
		Configuration conf=new Configuration();
		FileSystem hdfs=FileSystem.get(conf);
	
	    Job job1=new Job(conf,"planning");
		job1.setJarByClass(MyDriver.class);
		Path newfolder1=new Path(args[1]);
		job1.setMapperClass(MyMap.class);
	
		job1.setReducerClass(MyReduce.class);
		
		job1.setNumReduceTasks(1);
		job1.setMapOutputKeyClass(Text.class);
		job1.setMapOutputValueClass(IntWritable.class);
		try{
				FileInputFormat.addInputPath(job1, new Path(args[0]));
				if(hdfs.exists(newfolder1));
				   hdfs.delete(newfolder1,true);
			}
			catch(Exception e)
			{
				Logger 	log=Logger.getLogger("Error Message");
				log.log(Level.SEVERE,"Error Message {0}",e.getMessage());
			}
			FileOutputFormat.setOutputPath(job1, newfolder1);
			if(job1.waitForCompletion(true))
				hdfs.copyToLocalFile(newfolder1,new Path("/home/cloudera/Desktop/output"));		
	
		
	}

}
