package education;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class EducationReducer extends Reducer<Text,Text,Text,Text> {
	public void reduce(Text inkey,Iterable<Text> inval,Context context) throws IOException, InterruptedException
	{
		int employed=0;
		int unemployed=0;
		
		for(Text val:inval)
		{
			
			String s=val.toString();
			if(s.equals("0"))
			{
				unemployed++;
			}
			else
			{
				
				employed++;
			}
			
		}
		
		String value=
				"Total employed is:"+ employed +"Total Unemployed is:"+ unemployed;
		context.write(inkey,new Text(value));
		
		
	}

}