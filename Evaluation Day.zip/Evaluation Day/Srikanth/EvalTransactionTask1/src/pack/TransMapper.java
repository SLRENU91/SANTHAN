package pack;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TransMapper extends Mapper<LongWritable,Text,Text,Text>
{
	public void map(LongWritable inkey,Text inval,Context context) throws IOException, InterruptedException
	{
		String Rec = inval.toString();
		String[] RecArr = Rec.split(",");
		
		String Uid = "Uid "+RecArr[2];
		String Amount = "Amt "+RecArr[3];
		
		Text outkey = new Text(Uid);
		Text outval = new Text(Amount);
		
		context.write(outkey, outval);
		
		
	}
}
