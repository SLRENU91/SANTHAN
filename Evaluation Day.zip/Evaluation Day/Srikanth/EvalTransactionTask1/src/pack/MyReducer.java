package pack;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text,Text,Text,Text>
{
	public void reduce(Text inkey, Iterable<Text> inval,Context context) throws IOException, InterruptedException
	{
		String CustName = "";
		double CustTotal = 0.0;
		int TxnCount = 0;
		
		for (Text t : inval) 
		{
			String line = t.toString();
			String[] arr = line.split(" ");
						
			if (arr[0].equals("Amount")) 
			{
				TxnCount++;
				CustTotal += Double.parseDouble(arr[1]);
			} 
			else if (arr[0].equals("Name")) 
			{
				CustName = arr[1];
			}
		}
		String OutputString = CustName+" did a total of "+TxnCount+" transaction with total spendings of INR."+CustTotal;
		context.write(new Text(OutputString), null);
			
		}
}
