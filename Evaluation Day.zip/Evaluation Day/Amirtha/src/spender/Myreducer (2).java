package spender;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Myreducer extends Reducer<Text, Text, Text, NullWritable> {
	
	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		String userName = "";
		double Total = 0.0;
		int TxnCount = 0;		
		for (Text SingleVal : values) {
			String NumParts[] = SingleVal.toString().split(":");
			if (NumParts[0].equals("Amt")) {
				TxnCount++;
				Total += Double.parseDouble(NumParts[1]);
			} 
			else if (NumParts[0].equals("Name")) {
				userName = NumParts[1];
			}
		}
		String OutputString = userName+" "+TxnCount+" "+Total;
		context.write(new Text(OutputString), null);
	}
}
