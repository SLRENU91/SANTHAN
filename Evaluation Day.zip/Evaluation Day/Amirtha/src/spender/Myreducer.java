package spender;

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Myreducer extends Reducer<Text, Text, Text, Text> {
	
	
		HashMap<String, Integer> hm = new HashMap<>();
		HashMap<Integer,String> hm2= new HashMap<>();
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		String userName = "";
		double Total = 0.0;
		int TxnCount = 0;		
		for (Text SingleVal : values) {
			String NumParts[] = SingleVal.toString().split(":");
			
			if (NumParts[0].equals("Amt")) {
				TxnCount++;
				Total += Double.parseDouble(NumParts[1]);
			} 
			else if (NumParts[0].equals("Name")) {
				userName = NumParts[1];
			}
		}
		String OutputString = userName+" "+TxnCount+" "+Total;
		
		double max=0.0;
		Text outVal=new Text(OutputString);
		for(Text singlevalue: values){
			String inpStr =singlevalue.toString();
			String[] eachVal= inpStr.split(" ");
			double val=Double.parseDouble(eachVal[2]);
			if(max<val){
				max=val;
				outVal= new Text(inpStr);
				}
		}
		String s=Double.toString(max);
		Text outKey = new Text(s);
	context.write(outKey,outVal);
		
		

	}
}
