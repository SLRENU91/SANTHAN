package pack1;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReduce extends Reducer<Text, Text, Text, Text>
{
	public void reduce(Text InpKey, Iterable<Text> InpVal, Context c) throws IOException, InterruptedException{
	double totalincome = 0;
	int count = 0;
	for(Text myval: InpVal){
		totalincome+=Double.parseDouble(myval.toString());
		count++;
		}
	double avgincome=totalincome/count;
	Text OutKey = new Text("Age Group " + InpKey);
	Text OutVal = new Text(" Average salary is " +avgincome);
	c.write(OutKey,OutVal);

	}
	
}
