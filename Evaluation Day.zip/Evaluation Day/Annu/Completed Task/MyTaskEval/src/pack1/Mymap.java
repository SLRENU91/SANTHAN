package pack1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mymap extends Mapper<LongWritable, Text, Text, Text> 
{
	HashMap<String, String> ageType = new HashMap<>();
	
	public void setup(Context c) throws IOException
	{
		Path[] allFiles = DistributedCache.getLocalCacheFiles(c.getConfiguration());		
		
		for(Path eachFile : allFiles){
			if(eachFile.getName().equals("agegroup.dat"))
			{
				FileReader fr = new FileReader(eachFile.toString());
				BufferedReader br = new BufferedReader(fr);
				String line =br.readLine();
				while(line != null){
					String[] myvalue = line.split("\t");
					String age = myvalue[0];
					String grp = myvalue[1];
					ageType.put(age, grp);
					line =br.readLine();
				}
				br.close();
			}
			if (ageType.isEmpty()) 
			{
				throw new IOException("Unable To Load Customer Data.");
			}
		}
		
	}
	
	public void map(LongWritable mInpKey, Text mInpVal, Context c ) throws IOException, InterruptedException
	{
		String[] myvalue = mInpVal.toString().split(",");
		String[] FirstVal = myvalue[0].split(" ");
		String age = FirstVal[1];
		String group = ageType.get(age);
		String[] sixthVal = myvalue[5].split("  ");
		String sal = sixthVal[1];
		c.write(new Text(group), new Text(sal));	
	}

}
