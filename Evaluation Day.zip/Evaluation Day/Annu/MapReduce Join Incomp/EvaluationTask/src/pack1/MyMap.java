package pack1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMap extends Mapper<LongWritable, Text, Text, Text>
{
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
	{
				
		//{"Age": 73,"Education": " High school graduate","MaritalStatus": " Widowed","Gender": " Female","TaxFilerStatus": " Nonfiler","Income":  1700.09,"Parents": " Not in universe","CountryOfBirth": " United-States","Citizenship": " Native- Born in the United States","WeeksWorked":  0}

		
		String Record = value.toString();
		String Data = Record.substring(1,Record.length()-1);
		
		String RecordParts[] = Data.split(",");
		String Age = RecordParts[0];
		String Income = RecordParts[5]; 
		
		String RecordParts1[] = Age.split(": ");
		String RecordParts2[] = Income.split(":  ");
		
		String Age1 = RecordParts1[1];
		String Income1 = RecordParts2[1]; 
		
		Text OutPutKey = new Text(Age1);
		Text OutPutValue = new Text(Income1);
		context.write(OutPutKey,OutPutValue);
	}
}

