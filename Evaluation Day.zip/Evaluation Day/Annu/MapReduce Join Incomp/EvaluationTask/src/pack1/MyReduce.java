package pack1;


import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReduce extends Reducer<Text, Text, Text, NullWritable> 
{
	
	public void reduce(Text key, Text values, Context context) throws IOException, InterruptedException 
	{	
		double IncomeTotal = 0.0;	
		int count=0;
		double avg=0.0;
		String[] eachVal = values.toString().split(",");
			if (eachVal[0].equalsIgnoreCase("Infant"))
			{
				for(int i = 1;i < eachVal.length;i++)
				{
					IncomeTotal += Double.parseDouble(eachVal[i]);
					count++;
					
				}
				avg=IncomeTotal/count;
				Text rOut= new Text(key +" " +avg);
				context.write(rOut, null);
				
			} 
		}
	}