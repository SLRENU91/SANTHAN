import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable, Text, Text, Text> {
	HashMap<String, String> ageGrp = new HashMap<>();
	public void setup(Context c) throws IOException{
		Path[] allFiles = DistributedCache.getLocalCacheFiles(c.getConfiguration());		
		for(Path eachFile : allFiles){
			if(eachFile.getName().equals("agegroup.dat")){
				FileReader fr = new FileReader(eachFile.toString());
				BufferedReader br = new BufferedReader(fr);
				String line =br.readLine();
				while(line != null){
					String[] eachVal = line.split("\t");
					String age = eachVal[0];
					String grp = eachVal[1];
					ageGrp.put(age, grp);
					line =br.readLine();
				}
				br.close();
			}
			if (ageGrp.isEmpty()) 
			{
				throw new IOException("Unable To Load Customer Data.");
			}
		}
		
	}
	public void map(LongWritable mInpKey, Text mInpVal, Context c ) throws IOException, InterruptedException{
		String[] eachVal = mInpVal.toString().split(",");
		String[] FirstVal = eachVal[0].split(" ");
		String age = FirstVal[1];
		String group = ageGrp.get(age);
		String[] fourthVal = eachVal[3].split(":");
		String gender = fourthVal[1];
		c.write(new Text(group), new Text(gender));
		
	}

}
