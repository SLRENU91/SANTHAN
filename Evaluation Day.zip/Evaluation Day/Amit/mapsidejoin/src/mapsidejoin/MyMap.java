package mapsidejoin;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMap extends Mapper<LongWritable,Text, Text, Text> {
    
	private Map<Text, Text> CustDetails = new HashMap<Text, Text>();		
	
	protected void setup(Context context) throws java.io.IOException, InterruptedException{
		
		Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());		
		for (Path SinglePath : files) {
			if (SinglePath.getName().equals("agegroup.dat")) 
			{
				BufferedReader reader = new BufferedReader(new FileReader(SinglePath.toString()));
				String line = reader.readLine();
				while(line != null) 
				{
					String[] lineParts = line.split("\t");
					String age = lineParts[0];
					String agegroup = lineParts[1];
					
					CustDetails.put(new Text(age), new Text(agegroup));
					
				}
				reader.close();
			}
		}
		if (CustDetails.isEmpty()) 
		{
			throw new IOException("Unable To Load Customer Data.");
		}
	}
	
    protected void map(LongWritable key, Text value, Context context) throws java.io.IOException, InterruptedException 
    {    	   	
    	String Record = value.toString();
		String RecordParts[] = Record.split(",");
		
		Text age=new Text(RecordParts[0].split(" ")[1]);
		Text salary=new Text(RecordParts[5].split(" ")[2]);
		
		Set<Text> agevalues=CustDetails.keySet();
		Iterator<Text> ageitr=agevalues.iterator();
		
		while(ageitr.hasNext())
		{
			Text agevalue=new Text(ageitr.next().toString());
			if(agevalue.toString().equals(age.toString()))
			{
				context.write(CustDetails.get(agevalue),salary);
			}
		}
		
				
		
		
		
		
		
		
				
		 }  
}

