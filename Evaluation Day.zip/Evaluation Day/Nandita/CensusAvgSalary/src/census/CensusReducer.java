package census;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CensusReducer extends Reducer<Text, Text, Text, DoubleWritable> {
	int grandtotal=0;
	double grandsum=0;
	public void reduce(Text inkey, Iterable<Text> invalue, Context context) throws IOException, InterruptedException
	{
		double sum=0.0;
		int count=0;
		for(Text value : invalue)
		{
			String age = value.toString();
			sum += Double.parseDouble(age);
			count ++;
		}
		grandsum+=sum;
		grandtotal+=count;
		double average = sum/count;
		
		context.write(inkey,new DoubleWritable(average));
	}
	@Override
	protected void cleanup(Reducer<Text, Text, Text, DoubleWritable>.Context context)
			throws IOException, InterruptedException {
		 context.write(new Text("Overall Average"), new DoubleWritable(grandsum/grandtotal));
	}
	
}
