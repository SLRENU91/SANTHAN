package census;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CensusMapper extends Mapper<LongWritable, Text, Text, Text> {
	public TreeMap<Text,Text> AgeGroups=new TreeMap<>();
	private static Log logger = LogFactory.getLog(CensusMapper.class);
	@Override
	protected void setup(Mapper<LongWritable,Text,Text,Text>.Context context) throws java.io.IOException ,InterruptedException {
		Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());	
//		FileInputStream fis = new FileInputStream("/home/hduser/demos/agegroup.dat");
		for (Path SinglePath : files) {
			if (SinglePath.getName().equals("agegroup.dat")) 
			{
		
		BufferedReader br = new BufferedReader(new FileReader(SinglePath.toString()));
	 
		String line = null;
		while ((line= br.readLine()) != null) {
			 
			String[]parts = line.split("\t");
			String age = parts[0];
			String agegroup = parts[1];
			AgeGroups.put(new Text(age), new Text(agegroup));
			}
			br.close();	
			}
		}
	}
	public void map(LongWritable inkey,Text invalue,Context context) throws IOException, InterruptedException{
		String value = invalue.toString();
		String[] tokens = value.split(",");
		Text age = new Text(tokens[0].split(" ")[1]);
		Text salary =new Text(tokens[5].split(" ")[2]);
		
		Set<Text> agevalues = AgeGroups.keySet();
		Iterator<Text> ageitr = agevalues.iterator();
		while(ageitr.hasNext()){
			Text agevalue = new Text(ageitr.next().toString());
			logger.info("AgeValue" + agevalue.toString());
			if(agevalue.toString().equals(age.toString())){
				context.write(AgeGroups.get(agevalue), salary);
			}
		}
		
	}

}
