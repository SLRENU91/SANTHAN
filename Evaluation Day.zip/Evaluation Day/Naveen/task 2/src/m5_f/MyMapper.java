package m5_f;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,Text>{

	
	protected void map(LongWritable key, Text value,Context context)
			throws IOException, InterruptedException {
		String line = value.toString();
		String lineParts[] = line.split(",");
		//IntWritable One = new IntWritable(1);
		
		if(!lineParts[3].isEmpty())
		{
		Double d=Double.parseDouble(lineParts[3]);
		if(d>=3.9)
		{
			Text inKey=new Text("1");
		//DoubleWritable d2=new DoubleWritable(d);
		context.write(inKey,new Text(lineParts[1]));
		}
		}
		
		/*String line = value.toString();
		String lineParts[] = line.split(",");
		for(String SingleWord : lineParts)
		{
			Text OutKey = new Text("Total movie");
			IntWritable One = new IntWritable(1);
			context.write(OutKey, One);				
		}*/

	}

}
