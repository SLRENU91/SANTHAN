package movie_task2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class mymap extends Mapper<LongWritable, Text,Text,Text> {
	
	public void map(LongWritable inKey,Text inval,Context context) throws  InterruptedException, IOException
	{
		
		String line=inval.toString();
		String[] lineparts=line.split(",");
		String years=lineparts[2];
	     String moviename=lineparts[1];
		  
	
			Text mapoutkey=new Text(years);
			Text movie=new Text(moviename);
			 context.write(mapoutkey, movie);
			
               
				


		
}
}