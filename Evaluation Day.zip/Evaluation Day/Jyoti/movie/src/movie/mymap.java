package movie;

import org.apache.hadoop.io.Text;

import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Mapper;



public class mymap extends Mapper<LongWritable, Text,Text,Text> {
	
	public void map(LongWritable inKey,Text inval,Context context) throws  InterruptedException, IOException
	{
		
		String line=inval.toString();
		String[] lineparts=line.split(",");
	     String moviename=lineparts[1];
	  

		Text OutKey = new Text("1");
	Text movie=new Text(moviename);
		context.write(OutKey, movie);				


		
}
}