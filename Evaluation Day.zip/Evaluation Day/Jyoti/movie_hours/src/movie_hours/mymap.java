package movie_hours;



import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class mymap extends Mapper<LongWritable, Text,Text,Text> {
	
	public void map(LongWritable inKey,Text inval,Context context) throws  InterruptedException, IOException
	{
		
		String line=inval.toString();
		String[] lineparts=line.split(",");
		  try
		  {
		  String years=lineparts[4];
		     String moviename=lineparts[1];
		  Integer hrs=Integer.parseInt(years);
		
  		if(hrs > 5400)
	{
		

  			Text OutKey = new Text("1");
  		Text movie=new Text(moviename);
  			context.write(OutKey, movie);	
}		

		  }catch(ArrayIndexOutOfBoundsException e)
		  {
			  
			System.out.println(e.toString());
		  }
		  
		
}}