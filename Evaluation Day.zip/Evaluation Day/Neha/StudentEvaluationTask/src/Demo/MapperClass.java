package Demo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<LongWritable,Text,Text,Text>
{
	private Map<String, String> map = new HashMap<String, String>();
	@Override
	protected void setup(Context context) throws IOException, InterruptedException 
	{
		Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());		
	for (Path SinglePath : files) {
		if (SinglePath.getName().equals("student.dat")) 
		{
			BufferedReader reader = new BufferedReader(new FileReader(SinglePath.toString()));
		String line="";
		while((line=reader.readLine())!=null)
		{//vineet||1
			String data[]=line.split("\\|+\\|+");
			String id=data[1];
			String name=data[0];
			map.put(id,name);//1,vineet
		}
		reader.close();
		}
	}
	if (map.isEmpty()) 
	{
		throw new IOException("Unable To Load Data.");
	}
	}
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
		//1||fail
		String[] tData=value.toString().split("\\|+\\|+");
		String tid=tData[0];//1
		String tstatus=tData[1];//fail
		String tname=map.get(tid);//vineet
		String tdetails=tname+" has "+tstatus+"ed";
	//if(tname!=null)
		context.write(new Text(tstatus), new Text(tdetails));
	}
}
