package Demo;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class DriverClass 
{
	public static void main(String []arg) throws IOException, ClassNotFoundException, InterruptedException
	{
	Configuration con=new Configuration();
	Job job=new Job(con,"Student evaluation demo");//throws IOException
	job.setJarByClass(DriverClass.class);
	job.setNumReduceTasks(2);
	job.setMapperClass(MapperClass.class);
	job.setPartitionerClass(PartitionerClass.class);
	job.setReducerClass(ReducerClass.class);
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(Text.class);
	FileInputFormat.addInputPath(job,new Path(arg[0]));
	FileOutputFormat.setOutputPath(job,new Path(arg[1]));
	try 
	{
		DistributedCache.addCacheFile(new URI("/student.dat"),job.getConfiguration());
	} 
	catch (URISyntaxException e) 
	{
		e.printStackTrace();
	}
	System.exit(job.waitForCompletion(true)?0:1);
	}
}
