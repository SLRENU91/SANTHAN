package student;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class mypart extends Partitioner <Text,Text>{

	@Override
	public int getPartition(Text arg0, Text arg1, int arg2) {
		// TODO Auto-generated method stub
		
		
		
		String s1 = arg1.toString();
		if(s1.startsWith("f")){
			return 0;
		}
		else if(s1.startsWith("p")){
			return 1;
		}
		else {
			return 2;
		}
		//return arg2;
		
		
		
		
		
		//return arg2;
	}

}
