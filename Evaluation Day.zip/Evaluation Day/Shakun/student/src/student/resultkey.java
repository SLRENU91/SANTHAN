package student;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class resultkey extends Mapper<LongWritable,Text,Text,Text>
{
	
	private Map<String, String> StudentDetails = new HashMap<String, String>();	
	//static String StudentName="";
	protected void setup(Context context) throws java.io.IOException, InterruptedException{
		Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());		
		for (Path SinglePath : files) {
			if (SinglePath.getName().equals("results.dat")) 
			{
				BufferedReader reader = new BufferedReader(new FileReader(SinglePath.toString()));
				String line = reader.readLine();
				while(line != null) 
			{
					String[] lineParts = line.split("\\|+\\|+");
					String StuUid = lineParts[0];
					String StuStatus = lineParts[1];
					StudentDetails.put(StuUid, StuStatus);
					line = reader.readLine();
				}
				reader.close();
			}
		}
		if (StudentDetails.isEmpty()) 
		{
			throw new IOException("Unable To Load Student Result.");
		}
	}
		
	
	
public void map(LongWritable Key,Text value, Context context) throws java.io.IOException,InterruptedException{
		
	String Record = value.toString();
	String RecordParts[] = Record.split("\\|+\\|+");
	String Name = RecordParts[0];
	
	//String StuUid = RecordParts[1];
	
   // String StuUid =  StudentDetails.get(RecordParts[0]);
    String Result = StudentDetails.get(RecordParts[1]);
   // Text OutPutUid = new Text("Stuid:"+StuUid);
	Text OutPutName = new Text(Name);
	Text OutPutStatus = new Text(Result);
	
	
	  	context.write(OutPutName,OutPutStatus);

		
	}

}


