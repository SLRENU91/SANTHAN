package com.niit.mks;

public class MyMapper {

}
