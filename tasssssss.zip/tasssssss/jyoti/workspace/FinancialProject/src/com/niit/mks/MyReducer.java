package com.niit.mks;

public class MyReducer {

}
