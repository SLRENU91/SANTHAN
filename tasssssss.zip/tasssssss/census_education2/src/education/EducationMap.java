package education;


import java.io.IOException;


import org.apache.hadoop.io.LongWritable;

import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Mapper;

public cl
ass EducationMap extends Mapper<LongWritable,Text,Text,Text>
 {

	
public void map(LongWritable inkey,Text inval,Context context) throws IOException, InterruptedException


{
		

String value=inval.toString();

String lineparts[]=value.split(",");


String outkey=lineparts[1];

String outvalue=lineparts[9].trim();

context.write(new Text(outkey),new Text(outvalue));


}
}
