package com.furniturestore.dao;

import com.furniturestore.model.CardDetail;


public interface CardDetailDao {

    void addCardDetail (CardDetail cardDetail);

}
