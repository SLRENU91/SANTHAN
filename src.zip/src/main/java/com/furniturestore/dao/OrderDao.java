package com.furniturestore.dao;

import com.furniturestore.model.UserOrder;


public interface OrderDao {

    void addOrder(UserOrder userOrder);

}
