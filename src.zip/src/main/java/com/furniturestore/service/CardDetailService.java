package com.furniturestore.service;

import com.furniturestore.model.CardDetail;



public interface CardDetailService {

    void addCardDetail (CardDetail carddetail);

}
